// ==UserScript==
// @name          Torrentz All-in-One
// @description   Does everything you wish Torrentz.eu could do!
// @version       2.0.23
// @date          2013-02-23
// @author        elundmark
// @contact       mail@elundmark.se
// @license       CC0 1.0 Universal; http://creativecommons.org/publicdomain/zero/1.0/
// @namespace     http://elundmark.se/code/tz-aio/
// @homepage      https://userscripts.org/scripts/show/125001
// @updateURL     https://userscripts.org/scripts/source/125001.meta.js
// @downloadURL   https://userscripts.org/scripts/source/125001.user.js
// @supportURL    https://github.com/elundmark/tz-aio-userscript/issues
// @include       http*://torrentz.ph/*
// @include       http*://torrentz.eu/*
// @include       http*://torrentz.li/*
// @include       http*://torrentz.com/*
// @include       http*://torrentz.me/*
// @include       http*://torrentz.in/*
// @include       http*://torrentz.hk/*
// @include       http*://torrents.de/*
// @include       http*://tz.ai/*
// @require       http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js
// @grant         GM_log
// @grant         unsafeWindow
// @icon          data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAMAAAD04JH5AAACqVBMVEUKFB4KFR8LFR8LFiELFiIMGCQNGicNGigNGygNGykOHCsPGSIPHi0PHi4PHy8QIDEQITEQITIRGyQRIjMTJjoUKDwUKD0VJDUWHykWLEIXICoXL0cYIisYMEgZIiwZMksaIywaNE4cOVYdJi8dOlcdO1keJzAePFoePVwfKDEfPl4fP14fV48gKjMgQGAgQGEhQmMhQ2UiRWcjRmkkLTYkSW0lSm8mTHImTXMnTnYpUnspXpQqVH4rV4IsWIQsWIUsWYUsWYYtNT4tWocuSWQvSmQvXo4xYpMxYpQxY5QxY5UyOkIyZJcyZZcyZZgzZpk1Z5o2PkY2aJo3P0c3P0g6Qko6a5w8REw9RU1ASFBAcJ9BSVFBUGBCSlJCcaBDcqFEc6FFTVRFdKJGU19GaY1HT1ZJYHdJdqRMeaVNV2FNc5hOWGJRWF9TfqhTfqlUW2JWfKJaYWdaYWhad5Rag6xbhK1dY2pdhq5fh65giK9iibBjaXBjirFla3FlhKJli7FnbXNnbXRnjbJnjbNobnRqj7Rtc3ltkrZvk7dzlrl1e4F6m7x7nL18nL1/hIqCocCEo8GFo8KHpcOLqMWMkZaMnrCOlp6OqsaSorGTmJyVr8qWsMqYnKCZnaGanqKas8ybtMyctM2guM+nvdKovdOtwdWywtK7vsG/wsTC0eDFx8rGyMvHycvJy83Jy87Nz9HN09rP2ubQ2uTQ3OfT3ejU3+nX2dra3N3c3d/d3+Dg4uTh4uPi4+Tk5ufk6/Ho7fHo7fPp6uzp7vTq6+zq7/Tr7O3r7O7r7/Pr8PXs7e7s8PXu8fTv8/bw8fHw8fLy9fj09PX09/j19vf29vf2+Pr3+Pr3+fr4+Pn5+fn5+fr6+vr6+/z7+/v7/P38/Pz8/P39/f3+/v7///+abyX6AAAC3ElEQVR42u3b51MTQRzH4RWUiIqIXRR7Q1EUuyiW2FDD2bAX7L0rIhZUUMHeK/ZesPfeULF3seHt9y8xkzsEjtWJXLzL6O+TV5nszD252exekjkGkyMAAQiQCeAwOK4BICjU0IKgBYRKhhZKAAIQgAAEIAABCEAAAhCAAARwa8BGcOeLkkTFApxjTh4B6+F8vEOwJGg1ZABjgg0AVPORBB0DBxDpkzfAuj8C+Em5i4OjSL+8ATbwXEGGPVnwQk3BQeZ+47IeQNLFMyk5O3mDwx6/ciJF06WKuQ4yZe87LkMPoG9Ux8CcVd4ERyv8AzXVY8WkrEbErNx//o4MGXoA9lo1DMnZZuUMJHjXDtHWVFJLhCPl3esACNuhAnzbSb8skUPpXwYsduszsByf1dJlbjBArShTW2MSoFF9tW3GzQFx+/7aHCCAswCaAwRwOWAnzYH/HkBzwF0A0WbPged3Hz3J3q14A8+AqNcLrTYjAdqvi/LbiZXCjQRg99QZatMnHYWM48XLdTF0DiTk87KojedAWlkWEG7sx7BIk5ZKo97LSO/GCrWIMHgdsCrPh14APi1g+RvYzFmIehzinCd7sCo2k/aCtQBOe7DSnU1aimPAkVqBlWgrmQOY/Ax40Y95N5fMAQw7C3ydxzzrRphzPdDrIMCTGQvobtJ2vAocpwqzUp0kcwBLvgPXGjPf1iZ9NZvwAHjTh3k1izDlemBRmXPgiGaetWzS79oDx/CeLt8Nl20Bz9jOWHnRCpTEMwNk2MvgP/sS7xrAkY/gV0f3HjxtltLscYJfyUQ9nRmmG6Ak49X1m7fvqT0+4CQgbXgNl8wBxyN7h8O6Ogmorg+w9eXD+4JSd7Gs/WDpB2WMqMsDdALGxo4cJGhIe9ZGymzgfGWMqP7+VXUAHJW0FBRksVi1Y8QVqEP/GxKAAAQgAAEIQAACEIAABCAAAbQAd7vdj8PgON1zSgACuAvgB4QHvuWvZtCMAAAAAElFTkSuQmCC
// ==/UserScript==
(function(_window, $j){
  var currProtocol = location.protocol,
      currHost     = location.hostname,
      storedSettings, init, TZO,
      GM_log       = function (msg) {
        // redirects logs from error console to the more usable console
        if ( typeof _window !== "undefined"  && _window.console && _window.console.log ) {
          _window.console.log("-------- TzAio GM_log --------");
          _window.console.log(msg);
        }
      }
  ;
  try {
    if ( currProtocol === "http:" ) {
      location.href = location.href.replace(/^http:/, "https:");
    } else {
      // Main init function, called right after it's been closed
      init = function(){

        if ( typeof $j !== "function" || typeof _window !== "object" ) throw "We have no _window (or) $j";
        
        if ( typeof _ === "function"
          && typeof $j === "function"
          && typeof $j.toJSON === "function"
          && typeof $j.jStorage === "object"
          && !/^announcelist_/.test(document.location.pathname.replace(/\x2F/g,"")) ) {
          // ***************************************************************************************
          TZO = {
            torrHash         : document.location.pathname.replace(/\x2F/g,""),
            scriptName       : "tz_aio",
            scriptVersion    : "Version 2.0.23 2013-02-23",
            docDomain        : document.domain,
            scriptHomepage   : "http://userscripts.org/scripts/show/125001",
            cloakerUrl       : "http://href.li/?",
            bodyEl           : $j("body"),
            defTrackerList   : [
"http://tracker.openbittorrent.com:80/announce",
"udp://tracker.openbittorrent.com:80/announce",
"http://tracker.publicbt.com:80/announce",
"udp://tracker.publicbt.com:80/announce",
"http://tracker2.istole.it:6969/announce",
"http://tracker.istole.it:80/announce",
"http://inferno.demonoid.com:3407/announce",
"http://tracker.ilibr.org:6969/announce",
"http://tracker.prq.to/announce",
"http://tracker.torrent.to:2710/announce",
"http://9.rarbg.com:2710/announce",
"http://bt1.the9.com:6969/announce",
"http://exodus.desync.com:6969/announce",
"http://genesis.1337x.org:1337/announce",
"http://nemesis.1337x.org:80/announce"
            ],
            searchEnginesArr : [
"search_imdb|http://www.imdb.com/find?s=all&amp;q=%s",
"rotten_tomatoes|http://www.rottentomatoes.com/search/full_search.php?search=%s",
"itunes|http://ax.itunes.apple.com/WebObjects/MZSearch.woa/wa/search?term=%s",
"amazon|http://www.amazon.com/s/?field-keywords=%s",
"wikipedia|http://en.wikipedia.org/w/index.php?search=%s",
"google|https://www.google.com/search?q=%s"
            ],
            colors              : {
              tzblue     : "#369",
              tzpink     : "#f5dfd6",
              lightpink  : "#faefeb",
              white      : "#fff",
              black      : "#000",
              logohover  : "#b3cce6",
              darkgray   : "#333",
              milkwhite  : "#eee",
              offwhite   : "#fefefe",
              green      : "#00b900",
              brown      : "#805B4D",
              gray       : "#AAA",
              lightgray  : "#ccc",
              lightgreen : "#d4ffd4",
              orange     : "#F51"
            },
            
            
            addStyle         : function(css) {
              $j("head").append("<style type='text/css'>\n" + css + "\n</style>");
            },
            makeBool         : function(e) {
              return (/^true$/i).test(e);
            },
            removeDocOnclick : function() {
              if ( document.onclick !== null ) document.onclick = null;
            },
            currentSettings  : function(){
              return {
                versionCheck    : $j.jStorage.get(this.scriptName+"_versionCheck"),
                removeAds       : $j.jStorage.get(this.scriptName+"_removeAds"),
                searchHighlight : $j.jStorage.get(this.scriptName+"_searchHighlight"),
                linkComments    : $j.jStorage.get(this.scriptName+"_linkComments"),
                defaultTrackers : $j.jStorage.get(this.scriptName+"_defaultTrackers"),
                searchEngines   : $j.jStorage.get(this.scriptName+"_searchEngines")
              };
            },
            finalTrackerSorting : function(_arr){
              var sortArr = function(a,b) {
                a = a.toLowerCase().replace(/^(htt|ud)p:\/\//,"").replace(/\/$/,"");
                b = b.toLowerCase().replace(/^(htt|ud)p:\/\//,"").replace(/\/$/,"");
                a = a.match(/^\d+\.\d+\.\d+\.\d+/) ? a.replace(/^(\d+)\./,"$1")
                  : !a.match(/^[a-z0-9-]+\.[a-z0-9-]+\./) ? a
                  : a.match(/^[a-z0-9-]+\.[a-z0-9-]+\./) ? a.replace(/[a-z0-9-]+\.([a-z0-9-]+\.)/,"$1")
                  : a;
                b = b.match(/^\d+\.\d+\.\d+\.\d+/) ? b.replace(/^(\d+)\./,"$1")
                  : !b.match(/^[a-z0-9-]+\.[a-z0-9-]+\./) ? b
                  : b.match(/^[a-z0-9-]+\.[a-z0-9-]+\./) ? b.replace(/[a-z0-9-]+\.([a-z0-9-]+\.)/,"$1")
                  : b;
                if ( a == b ) { return 0; }
                if ( a > b )  { return 1; } else { return -1; }
              }, newArr = [];
              _arr.sort(sortArr);
              for (var index = 0; index < _arr.length; index++) {
                var prev = index >= 1 ? _arr[(index-1)] : "",
                    udpPopped
                ;
                if ( prev.replace(/^udp/,"") == _arr[index].replace(/^https?/,"") ) {
                  udpPopped = newArr.pop();
                  newArr.push(_arr[index]);
                  newArr.push(udpPopped);
                } else {
                  newArr.push(_arr[index]);
                }
              }
              return newArr;
            },
            mergeTrackers    : function(stored, specific, format) {
              var mergedArray;
              if ( _.isArray(stored) && _.isArray(specific) ) {
                stored = _.compact(stored);
                specific = _.compact(specific);
                mergedArray = _.union(stored, specific);
                mergedArray = this.finalTrackerSorting(mergedArray);
                if ( format && format === "array") {
                  return mergedArray;
                } else if ( format && format === "string") {
                  return mergedArray.join("\n\n");
                }
              } else {
                throw "mergeTrackers got something else than an array";
              }
            },
            newlineDelimiter    : function(s){
              var localArr  = s.replace(/^\n+/,"").replace(/\n+$/,"").split(/\n+/),
                  newString = ""
              ;
              for (var index = 0; index < localArr.length; index++) {
                var next = (index+1) < localArr.length ? localArr[(index+1)] : "";
                if ( next.replace(/^udp/,"") == localArr[index].replace(/^https?/,"") ) {
                  newString += localArr[index] + "\n";
                } else {
                  newString += localArr[index] + "\n\n";
                }
              }
              newString = newString.replace(/\n+$/,"");
              return newString;
            },
            copyTextarea        : [],
            torrentTitles       : {
              raw     : "",
              encoded : ""
            },
            topDiv              : null,
            trackerObject       : {}
          // end TZO object
          };
          storedSettings = TZO.currentSettings();
          
          // Set default settings localStorage for the 1st run
          if ( storedSettings.versionCheck === null
            && storedSettings.removeAds === null
            && storedSettings.searchHighlight === null
            && storedSettings.linkComments === null
            && storedSettings.defaultTrackers === null
            && storedSettings.searchEngines === null ) {
            $j.jStorage.set(TZO.scriptName+"_versionCheck",TZO.scriptVersion);
            $j.jStorage.set(TZO.scriptName+"_removeAds",true);
            $j.jStorage.set(TZO.scriptName+"_searchHighlight",true);
            $j.jStorage.set(TZO.scriptName+"_linkComments", true);
            $j.jStorage.set(TZO.scriptName+"_defaultTrackers",TZO.defTrackerList);
            $j.jStorage.set(TZO.scriptName+"_searchEngines",TZO.searchEnginesArr);
            storedSettings = TZO.currentSettings();
          } else if ( $j.jStorage.get(TZO.scriptName+"_versionCheck") === null ) {
            // new version flush to circumvent errors (mean and lazy)
            alert("This version upgrade requires all stored data you have to be deleted, \
sorry about that. The page will refresh and new values set. Won't happen again :)");
            $j.jStorage.flush() && _window.location.reload();
          }
          
          TZO.trackerObject.userArray = storedSettings.defaultTrackers;
          TZO.trackerObject.userString = TZO.mergeTrackers( TZO.trackerObject.userArray, [], "string");
          
          TZO.bodyEl.addClass(TZO.scriptName + "_b");
          TZO.addStyle( TZO.css() );
          // Settings applies to all pages
          (function(){
            var settingsEl,
                settingsSubmitEl,
                resetEl,
                settingsVisible = false
            ;
            TZO.topDiv = $j("div.top:eq(0)");
            // Remove ads here since we have this function on every page
            if ( storedSettings.removeAds ) {
              TZO.removeDocOnclick();
              TZO.bodyEl.addClass("no_ads");
              $j("object, embed, iframe").addClass("removed_ad");
              $j("p.generic").has("iframe").addClass("removed_ad");
            }
            TZO.topDiv.find(" > ul").prepend("<li class='"+TZO.scriptName+"_settings'><a href='#' title='Change TzAio Settings'>TzAio</a>");
            settingsEl = TZO.topDiv.find(" > ul > li."+TZO.scriptName+"_settings a");
            TZO.topDiv.append("<div class='settings_wrap'><span id='trackers_title'>\
Default trackerlist (these are added to all torrents\' trackers, if absent)</span>\
<span id='searchengines_title'>Search engines list (title|url formatting, use %s to indicate keyword, and \"_\" to indicate a space)</span>\
<textarea title='Note that these are combined with the torrents own trackers, and after that duplicates are removed, \
they get sorted by domain, and finally grouped with any backup udp protocols.' id='default_trackers_textarea' wrap='off'>"
+ TZO.newlineDelimiter( TZO.mergeTrackers( [], storedSettings.defaultTrackers, "string" ) ) + "</textarea>\
<textarea id='default_searchengines_textarea' wrap='off' title='How to use: On the torrent page, select some text in the title \
with the name of the torrent, and the links listed here will appear as links underneith.'>" + storedSettings.searchEngines.join("\n") + "</textarea>\
<div id='other_settings'><a href='#' id='settings_reset'><span>Reset?</span></a>\
<p class='_title'>Main settings</p>\
\
<p>Hide Torrentz's Ads</p>\
<p class='inputs'><span class='lp'><input type='radio' name='removeAds' value='true' checked='checked' id='removeAds_true' />\
<label for='removeAds_true'>Yes</label></span><span class='rp'><input type='radio' name='removeAds' value='false' id='removeAds_false' />\
<label for='removeAds_false'>No</label></span></p>\
\
<p>Highlight search results</p>\
<p class='inputs'><span class='lp'><input type='radio' name='searchHighlight' value='true' checked='checked' id='searchHighlight_true' />\
<label for='searchHighlight_true'>Yes</label></span><span class='rp'><input type='radio' name='searchHighlight' value='false' \
id='searchHighlight_false' /><label for='searchHighlight_false'>No</label></span></p>\
\
<p>Fix comment links</p>\
<p class='inputs'><span class='lp'><input type='radio' name='linkComments' value='true' checked='checked' id='linkComments_true'>\
<label for='linkComments_true'>Yes</label></span><span class='rp'><input type='radio' name='linkComments' value='false' id='linkComments_false'>\
<label for='linkComments_false'>No</label></span></p>\
\
<button id='settings_submit'>SAVE &amp; REFRESH</button>\
</div></div>");
            if ( !storedSettings.removeAds ) $j("#removeAds_false").attr("checked", true);
            if ( !storedSettings.searchHighlight ) $j("#searchHighlight_false").attr("checked", true);
            if ( !storedSettings.linkComments ) $j("#linkComments_false").attr("checked", true);
            settingsSubmitEl = $j("#settings_submit");
            resetEl = $j("#settings_reset");
            
            settingsEl.click(function(){
              if ( TZO.topDiv.hasClass("expand") && settingsVisible ) {
                TZO.topDiv.removeClass("expand");
                settingsVisible = false;
              } else if ( !TZO.topDiv.hasClass("expand") && !settingsVisible ) {
                TZO.topDiv.addClass("expand");
                settingsVisible = true;
              }
              TZO.copyTextarea.length && TZO.copyTextarea.stop().hide(0);
              return false;
            });
            settingsSubmitEl.bind("click", function(){
              var saveTrackers,
                  saveSearchEngines
              ;
              TZO.topDiv.find("input:checked").each(function(){
                var el           = $j(this),
                    settingName  = el.attr("name"),
                    settingValue = TZO.makeBool(el.val())
                ;
                $j.jStorage.set(TZO.scriptName + "_" + settingName, settingValue);
              });
              saveTrackers = $j("#default_trackers_textarea").val().split(/\s+/);
              saveSearchEngines = $j("#default_searchengines_textarea").val().split(/\s+/);
              saveSearchEngines = _.compact(saveSearchEngines);
              $j.jStorage.set( TZO.scriptName+"_defaultTrackers",  saveTrackers);
              $j.jStorage.set( TZO.scriptName+"_searchEngines", saveSearchEngines);
              setTimeout(function(){
                _window.location.reload();
              }, 100);
            });
            
            resetEl.bind("click",function(){
              var refresh_page_reset = confirm("Reset settings and reload the page?");
              if ( refresh_page_reset ) $j.jStorage.flush() && _window.location.reload();
              return false;
            });
          // End settings panel
          })();
          
          // Page specific select (always remove ads first)
          if ( /^\w{40}$/i.test(TZO.torrHash) ) {
            var downloadDiv = $j(".download:eq(0)");
            // Remove specific ads
            if ( storedSettings.removeAds ) {
              (function(){
                var topInfoDiv = TZO.bodyEl.find(" > div.info"),
                    firstDl    = downloadDiv.find(" > dl:eq(0)"),
                    pImgAd     = topInfoDiv.prev().has("a img")
                ;
                if ( topInfoDiv.length && topInfoDiv.text().match(/btguard/i) ) topInfoDiv.addClass("removed_ad");
                if ( firstDl.text().match(/(direct\s+download|sponsored\s+link)/i) ) firstDl.addClass("removed_ad");
                if ( pImgAd.length ) pImgAd.addClass("removed_ad");
              })();
            }
            // Linkify comment links
            if ( storedSettings.linkComments ) {
              (function(){
                var commentEl = $j(".comment");
                setTimeout(function(){
                  // Linkify visible comments
                  if ( commentEl.length ) {
                    var regPatt      = /((http|https)\:\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!\:.?+=&%@!\-\/]))?)?/gi,
                        linkComments = commentEl.find(".com:visible:contains('http')")
                    ;
                    linkComments.each(function(){
                      var thisLink = $j(this);
                      thisLink.replaceText(regPatt, "<a href='" + TZO.cloakerUrl + "$1'>$1</a>" );
                    });
                  }
                }, 750);
              })();
            }
            // info bar
            (function(){
              // create all-in-one bar
              var currTrackerList= [],
                  trackersDiv    = $j("div.trackers:eq(0)"),
                  trackerLinks   = trackersDiv.find("dt a"),
                  trackerDataEls = trackersDiv.find("dl:has(a) dd"),
                  trackerLen,
                  torrTitle      = $j("h2:eq(0) span").text(),
                  mg_trackerList = "",
                  magnetLinkHtml = "",
                  announceUrl    = trackersDiv.find(" > p > a[href*='announcelist_']").attr("href"),
                  finalHtml      = "",
                  upElems        = trackerDataEls.find(".u"),
                  downElems      = trackerDataEls.find(".d"),
                  dhtEls         = trackersDiv.find("dl:eq(0):contains('(DHT)') span.u, dl:eq(0):contains('(DHT)') span.d"),
                  _up            = [],
                  _down          = [],
                  upNum          = 0,
                  downNum        = 0,
                  topUpNum       = 0,
                  topDownNum     = 0,
                  seedMeter      = 0,
                  seedTleach,
                  seedColor      = TZO.colors.black,
                  seedText,
                  minPeersText,
                  seedTitle      = "S<span class='divided'>&frasl;</span>L &asymp;",
                  filesDiv       = $j("div.files"),
                  fileLinks      = $j("a", filesDiv),
                  filesInfoText,
                  wmvWarning     = false,
                  notActive      = !!(downloadDiv.next(".error").text().match(/active\s+locations?/i)),
                  verDownload    = $j(".votebox .status").text().match(/\d+/),
                  verDownloadCl  = (verDownload && +verDownload[0] >= 3) && !notActive ? " verified_download" : notActive ? " not_active" : "",
                  warn_blink_timer,
                  filesSizeText  = $j("div:contains('Size:'):eq(0)", filesDiv).text().replace("Size: ",""),
                  commentDiv     = $j("div.comments"),
                  formFieldset   = $j("form.profile fieldset"),
                  commentCount   = $j(".comment", commentDiv).length,
                  htmlDivider    = " <span class='"+TZO.scriptName+"_sep'>&#124;</span> ",
                  trackersText,
                  commentText,
                  trackerNumText,
                  clippyText,
                  minPeers = 0,
                  formatNumbers  = function(i){
                    if ( i >= 1000 ) {
                      i = ""+i+"";
                      return (i.replace(/(\d+)(\d{3})$/,"$1,$2"));
                    } else {
                      return i;
                    }
                  }
              ;
              TZO.torrentTitles.raw = torrTitle;
              TZO.torrentTitles.encoded = encodeURIComponent( torrTitle.replace("'","") );
              trackerLinks.each(function() {
                // Will produce an empty array if there are no trackers on site
                currTrackerList.push( $j(this).text() );
              });
              TZO.trackerObject.siteArray = currTrackerList;
              TZO.trackerObject.siteString = TZO.mergeTrackers( [], TZO.trackerObject.siteArray, "string" );
              TZO.trackerObject.allArray = TZO.mergeTrackers( TZO.trackerObject.userArray, TZO.trackerObject.siteArray, "array" );
              TZO.trackerObject.allString = TZO.mergeTrackers( TZO.trackerObject.allArray, [], "string" );
              TZO.trackerObject.allMagnet = "magnet:?xt=urn:btih:" + TZO.torrHash + "&amp;dn="
              + TZO.torrentTitles.encoded + "&amp;tr=" + TZO.trackerObject.allString.replace(/\n+/g,"&amp;tr=");
              trackerLen = TZO.trackerObject.allArray.length;
              trackersText = trackerLen > 1 ? "trackers" : "tracker";
              // final magnetlink uri
              magnetLinkHtml = "<a class='"+TZO.scriptName+"_mlink' href='"
              + TZO.trackerObject.allMagnet 
              + "' title='Fully qualified magnet URI for newer BitTorrent clients, includes"
              + " all " + trackerLen + " " + trackersText + "'>Magnet Link</a>";
              // create seed leach ratio
              upElems.each(function(index) {
                _up[index]   = +$j(this).text().replace(/\D/g,"");
              });
              downElems.each(function(index) {
                _down[index] = +$j(this).text().replace(/\D/g,"");
              });
              for (var i = 0; i < _up.length; i++) {
                upNum += _up[i];
                if (i === 0) {
                  topUpNum = _up[i];
                } else if ( _up[i] > topUpNum ) {
                  topUpNum = _up[i];
                }
              }
              for (var i = 0; i < _down.length; i++) {
                downNum += _down[i];
                if (i === 0) {
                  topDownNum = _down[i];
                } else if ( _down[i] > topDownNum ) {
                  topDownNum = _down[i];
                }
              }
              // DHT activity
              minPeers = (topDownNum >= topUpNum) ? topDownNum : topUpNum;
              dhtEls.each(function(){
                var i = +$j(this).text().replace(/\D/g,"");
                if ( i > minPeers ) minPeers = i;
              });
              seedTleach = (upNum/downNum);
              seedTleach = ((topUpNum/topDownNum )+(seedTleach))/2;
              if (seedTleach === Infinity) {
                seedMeter = (upNum/_up.length).toFixed(2); // 8 divided by 0
              } else if (isNaN(seedTleach)) {
                seedMeter = 0; // 0 divided by 0
              } else if (seedTleach < 10) {
                seedMeter = seedTleach.toFixed(2);
              } else if (seedTleach >= 10 && seedTleach < 100) {
                seedMeter = seedTleach.toFixed(1);
              } else if (seedTleach >= 100) {
                seedMeter = Math.round(seedTleach);
              }
              if (seedMeter >= 2 && topUpNum >= 5 ) {
                seedColor = TZO.colors.green;
              }
              seedText = seedTitle + " <span style='color:" + seedColor + "'>" + seedMeter + "</span>";
              minPeersText = " <span>" + formatNumbers(minPeers) + "+ peers</span>";
              clippyText = "<a href='#' id='copylist' title='Click to copy the trackerlist'>Copy "
                          +TZO.trackerObject.allArray.length + " trackers</a>";
              if (commentCount) {
                commentText = "<a href='#comments_"+TZO.scriptName+"'>";
                commentDiv.attr("id","comments_"+TZO.scriptName);
              } else {
                commentText = "<a href='#write_comment_"+TZO.scriptName+"'>";
                formFieldset.attr("id","write_comment_"+TZO.scriptName);
              }
              commentText += "<img src='//"+TZO.docDomain+"/img/comment.png'/> " + commentCount+"</a>";
              fileLinks.filter("[href*='.wmv']").each(function(){
                if ( /\.wmv$/i.test($j(this).text()) ) {
                  wmvWarning = true;
                }
              });
              if (fileLinks.length) {
                $j("div.files:eq(0)").attr("id","files_"+TZO.scriptName);
                filesInfoText = "<a href='#files_"+TZO.scriptName+"'><img src='//"+TZO.docDomain+"/img/folder.png'/> " + fileLinks.length + "</a> &frasl; ";
              } else if (!fileLinks.length) {
                filesInfoText = "";
              }
              filesInfoText += filesSizeText.length ? filesSizeText : "";
              if ( filesInfoText.length && wmvWarning ) {
                filesInfoText += " <span class='warn'>.wmv</span>";
              }
              finalHtml += magnetLinkHtml;
              finalHtml += htmlDivider + clippyText;
              finalHtml += htmlDivider + minPeersText;
              finalHtml += htmlDivider + seedText;
              finalHtml += htmlDivider + commentText;
              finalHtml += filesInfoText.length ? htmlDivider + filesInfoText : "";
              finalHtml += " <a href='"+TZO.scriptHomepage+"' id='"+TZO.scriptName+"_logo'";
              finalHtml += " title='"+TZO.scriptVersion+"'>Tz Aio";
              finalHtml += "<span id='"+TZO.scriptName+"_message'>";
              finalHtml += "Visit Torrentz All-in-One Website ("+TZO.scriptVersion+")";
              finalHtml += "</span></a>";
              downloadDiv.before("<div id='" + TZO.scriptName + "' class='" + verDownloadCl + "'>" + finalHtml + "</div>");
              // edit torrentz own magnet link if avaliable
              downloadDiv.find("a[href^='magnet']").each(function(){
                $(this).attr("href", TZO.trackerObject.allMagnet
                                     .replace(/\&amp\;/ig,"&")
                                     .replace(/\&gt\;/ig,">")
                                     .replace(/\&lt\;/ig,"<")
                );
              });
              warn_blink_timer = setTimeout(function(){
                $j("#"+TZO.scriptName).find(".warn")
                .fadeOut(500).delay(550).fadeIn(500)
                .delay(550).fadeOut(500).delay(550).fadeIn(500)
                .delay(550).fadeOut(500).delay(550).fadeIn(500);
              }, 2000);
              // end info bar
              
              // Setup copy methods
              (function(){
                // flash method sux and has been abandoned
                var copylistEl   = $j("#copylist"),
                    copylistText = TZO.newlineDelimiter( TZO.trackerObject.allString ),
                    linkHeight   = copylistEl.outerHeight(),
                    theTextarea,
                    textareaHTML = "<div id='copy_tr_textarea'><textarea readonly='readonly' cols='40' rows='10' wrap='off'>"
                    + copylistText + "</textarea></div>"
                ;
                TZO.bodyEl.append(textareaHTML);
                TZO.copyTextarea = $j("#copy_tr_textarea");
                copylistEl.click(function(){
                  if ( TZO.copyTextarea.is(":hidden") ) {
                    TZO.copyTextarea.css({
                      top : (copylistEl.offset().top + linkHeight)+"px",
                      left : (copylistEl.offset().left)+"px"
                    }).show(0).find("textarea")[0].select();
                  } else {
                    TZO.copyTextarea.hide(0);
                  }
                  return false;
                });
              })();
              
            })();       
            
            // Download buttons
            (function(){
              // select the links we want to downloadify
              var torCacheUrl        = "http://torcache.net/torrent/" + TZO.torrHash.toUpperCase() + ".torrent?title=" + TZO.torrentTitles.encoded,
                  torRageUrl         = "http://torrage.com/torrent/" + TZO.torrHash.toUpperCase() + ".torrent",
                  torrSitesArr       = [
                    [ "movietorrents.eu",
                      function(theUrl){
                        // movietorrents.eu/torrents-details.php?id=1421
                        // movietorrents.eu/download.php?id=1421&name=Ubuntu%20iso%20file.torrent
                        // last checked 2012-07-25
                        return ( "http://movietorrents.eu/download.php?id=" + theUrl.match(/(\?|&)id=(\d+)/)[2]
                          + "&name=" + TZO.torrentTitles.encoded + ".torrent" );
                      }
                    ],
                    [ "publichd.eu",
                      function(theUrl){
                        // publichd.eu/index.php?page=torrent-details&id=bae62a9932ec69bc6687a6d399ccb9d89d00d455
                        // publichd.eu/download.php?id=bae62a9932ec69bc6687a6d399ccb9d89d00d455&f=ubuntu-10.10-dvd-i386.iso.torrent
                        // last checked 2012-07-23
                        return ( "http://publichd.eu/download.php?id=" + TZO.torrHash.toLowerCase() + "&f=" + TZO.torrentTitles.encoded + ".torrent" );
                      }
                    ],
                    [ "btmon.com",
                      function(theUrl){
                        // www.btmon.com/Applications/Unsorted/ubuntu-10.10-dvd-i386.iso.torrent.html
                        // www.btmon.com/Applications/Unsorted/ubuntu-10.10-dvd-i386.iso.torrent
                        // last checked 2012-05-13
                        return ( theUrl.replace(/\.html$/i, "") );
                      }
                    ],
                    [ "torrentdownloads.net",
                      function(theUrl){
                        // www.torrentdownloads.net/torrent/1652094016/ubuntu-10+10-desktop-i386+iso
                        // www.torrentdownloads.net/download/1652094016/ubuntu-10+10-desktop-i386+iso
                        // last checked 2012-05-13
                        return ( theUrl.replace(/(\.net\/)torrent(\/)/i,"$1download$2") );
                      }
                    ],
                    [ "kat.ph",
                      function(theUrl){
                        // www.kickasstorrents.com/ubuntu-10-10-dvd-i386-iso-t4657293.html
                        // torcache.net/torrent/BAE62A9932EC69BC6687A6D399CCB9D89D00D455.torrent?title=[kat.ph]ubuntu-10-10-dvd-i386
                        // last checked 2012-05-13
                        return ( torCacheUrl );
                      }
                    ],
                    [ "kickasstorrents.com",
                      function(theUrl){
                        // www.kickasstorrents.com/ubuntu-10-10-dvd-i386-iso-t4657293.html
                        // torcache.net/torrent/BAE62A9932EC69BC6687A6D399CCB9D89D00D455.torrent?title=[kat.ph]ubuntu-10-10-dvd-i386
                        // last checked 2012-05-13
                        return ( torCacheUrl );
                      }
                    ],
                    [ "h33t.com/tor",
                      function(theUrl){
                        // h33t.com/tor/999999/ubuntu-10.10-dvd-i386.iso-h33t
                        // h33t.com/download.php?id=bae62a9932ec69bc6687a6d399ccb9d89d00d455&f=Ubuntu%2010.10%20-%20DVD%20-%20i386.iso.torrent
                        // last checked 2012-05-13
                        return ( "http://h33t.com/download.php?id=" + TZO.torrHash.toLowerCase() + "&f="
                                +TZO.torrentTitles.encoded + "%5D%5Bh33t%5D.torrent" );
                      }
                    ],
                    [ "newtorrents.info/torrent",
                      function(theUrl){
                        // www.newtorrents.info/torrent/99999/Ubuntu-10-10-DVD-i386.html?nopop=1
                        // www.newtorrents.info/down.php?id=99999
                        // last checked 2012-05-13
                        var theUrlArr = theUrl.split("/");
                        return ( "http://" + theUrlArr[2] + "/down.php?id=" + theUrlArr[4] );
                      }
                    ],
                    [ "fenopy.eu/torrent",
                      function(theUrl){
                        // fenopy.com/torrent/ubuntu+10+10+dvd+i386+iso/NjMxNjcwMA
                        // fenopy.com/torrent/ubuntu+10+10+dvd+i386+iso/NjMxNjcwMA==/download.torrent
                        // seems to use torcache but this works too
                        // last checked 2012-05-13
                        return ( theUrl + "==/download.torrent" );
                      }
                    ],
                    [ "extratorrent.com/torrent",
                      function(theUrl){
                        // extratorrent.com/torrent/9999999/Ubuntu-10-10-DVD-i386.html
                        // extratorrent.com/download/9999999/Ubuntu-10-10-DVD-i386.torrent
                        // last checked 2012-05-13
                        return ( theUrl.replace(/(\.com\/torrent)/i, ".com/download").replace(/\.html$/i, ".torrent") );
                      }
                    ],
                    [ "bitsnoop.com",
                      function(theUrl){
                        // bitsnoop.com/ubuntu-10-10-dvd-i386-q17900716.html
                        // torrage.com/torrent/BAE62A9932EC69BC6687A6D399CCB9D89D00D455.torrent
                        // last checked 2012-05-13
                        return ( torRageUrl );
                      }
                    ],
                    [ "bt-chat.com",
                      function(theUrl){
                        // www.bt-chat.com/details.php?id=999999
                        // www.bt-chat.com/download.php?id=999999
                        // last checked 2012-05-13
                        // Site was malware flagged so I don't know if this still works
                        return ( theUrl.replace(/\/details\.php/i, "/download.php") );
                      }
                    ],
                    [ "1337x.org",
                      function(theUrl){
                        // 1337x.org/torrent/999999/ubuntu-10-10-dvd-i386/
                        // last checked 2012-05-13
                        return ( torCacheUrl );
                      }
                    ],
                    [ "torrentfunk.com/torrent/",
                      function(theUrl){
                        // www.torrentfunk.com/torrent/9999999/ubuntu-10-10-dvd-i386.html
                        // www.torrentfunk.com/tor/9999999.torrent
                        // last checked 2012-05-13
                        var theUrlArr = theUrl.split("/");
                        return ( "http://www.torrentfunk.com/tor/" + theUrlArr[4] + ".torrent" );
                      }
                    ],
                    [ "torrentstate.com",
                      function(theUrl){
                        // www.torrentstate.com/ubuntu-10-10-dvd-i386-iso-t4657293.html
                        // www.torrentstate.com/download/BAE62A9932EC69BC6687A6D399CCB9D89D00D455
                        // last checked 2012-05-13
                        // Site was down so I don't know if this still works
                        return ( "http://www.torrentstate.com/download/" + TZO.torrHash.toUpperCase() );
                      }
                    ],
                    [ "torlock.com/torrent/",
                      function(theUrl){
                        // www.torlock.com/torrent/1702956/21-jump-street-2012-r5-new-line-inspiral.html
                        // dl.torlock.com/1702956.torrent
                        // last checked 2012-05-13
                        var theUrlArr = theUrl.split("/");
                        return ( "http://dl.torlock.com/" + theUrlArr[4] + ".torrent" );
                      }
                    ],
                    [ "torrenthound.com/hash",
                      function(theUrl){
                        // www.torrenthound.com/hash/bae62a9932ec69bc6687a6d399ccb9d89d00d455/torrent-info/ubuntu-10.10-dvd-i386.iso
                        // www.torrenthound.com/torrent/bae62a9932ec69bc6687a6d399ccb9d89d00d455
                        // last checked 2012-05-13
                        return ( "http://www.torrenthound.com/torrent/" + TZO.torrHash );
                      }
                    ],
                    [ "vertor.com/torrents",
                      function(theUrl){
                        // www.vertor.com/torrents/2191958/Ubuntu-10-10-Maverick-Meerkat-%28Desktop-Intel-x86%29
                        // www.vertor.com/index.php?mod=download&id=2191958
                        // last checked 2012-05-13
                        var theUrlArr = theUrl.split("/");
                        return ( "http://www.vertor.com/index.php?mod=download&id=" + theUrlArr[4] );
                      }
                    ],
                    [ "yourbittorrent.com/torrent/",
                      function(theUrl){
                        // www.yourbittorrent.com/torrent/212911/ubuntu-10-10-desktop-i386-iso.html
                        // www.yourbittorrent.com/down/212911.torrent
                        // last checked 2012-05-13
                        var theUrlArr = theUrl.split("/");
                        return ( "http://yourbittorrent.com/down/" + theUrlArr[4] + ".torrent" );
                      }
                    ],
                    [ "torrents.net/torrent",
                      function(theUrl){
                        // www.torrents.net/torrent/9999999/Ubuntu-10-10-DVD-i386.html/
                        // www.torrents.net/down/9999999.torrent
                        // last checked 2012-05-13
                        var theUrlArr = theUrl.split("/");
                        return ( "http://www.torrents.net/down/" + theUrlArr[4] + ".torrent" );
                      }
                    ],
                    [ "torrentbit.net/torrent",
                      function(theUrl){                  
                        // www.torrentbit.net/torrent/1903618/Ubuntu11.04%20Desktop%20i386%20ISO/
                        // www.torrentbit.net/get/1903618
                        // last checked 2012-05-13
                        var theUrlArr = theUrl.split("/");
                        return ( "http://www.torrentbit.net/get/" + theUrlArr[4] );
                      }
                    ],
                    [ "coda.fm/albums",
                      function(theUrl){                  
                        // coda.fm/albums/9999
                        // coda.fm/albums/9999/torrent/download?file=Title+of+torrent.torrent
                        // last checked 2012-05-13
                        var theUrlArr = theUrl.split("/");
                        return ( "http://coda.fm/albums/" + theUrlArr[4] + "/torrent/download?file="
                                +TZO.torrentTitles.encoded + ".torrent" );
                      }
                    ],
                    [ "take.fm/movies",
                      function(theUrl){                  
                        // take.fm/movies/999/releases/9999
                        // take.fm/movies/999/releases/9999/torrent/download?file=Title+of+torrent.torrent
                        // last checked 2012-05-13
                        var theUrlArr = theUrl.split("/");
                        return ( "http://take.fm/movies/"+theUrlArr[4]+"/releases/"+theUrlArr[6]
                                +"/torrent/download?file="+TZO.torrentTitles.encoded+".torrent" );
                      }
                    ],
                    [ "torrage.com/torrent",
                      function(theUrl){
                        // torrage.com/torrent/BAE62A9932EC69BC6687A6D399CCB9D89D00D455.torrent
                        return theUrl;
                      }
                    ],
                    [ "torcache.net/torrent",
                      function(theUrl){
                        // torcache.net/torrent/BAE62A9932EC69BC6687A6D399CCB9D89D00D455.torrent
                        return theUrl;
                      }
                    ],
                    [ "zoink.it/torrent",
                      function(theUrl){
                        // zoink.it/torrent/BAE62A9932EC69BC6687A6D399CCB9D89D00D455.torrent
                        return theUrl;
                      }
                    ]
                  ],
                  linkList           = downloadDiv.find("a:not([href^='magnet']):not([href='"+TZO.scriptName + "_dllink'])"),
                  torrSitesArrLength = torrSitesArr.length
              ;
              linkList.each(function(){
                var theUrl    = this.href,
                    theUrlLow = theUrl.toLowerCase(),
                    theLink   = $j(this)
                ;
                for ( var j = 0; j < torrSitesArrLength; j++ ) {
                  if ( theUrlLow.match(new RegExp(torrSitesArr[j][0],"i")) ) {
                    theLink.before("<a href='" + torrSitesArr[j][1](theUrl) + "' class='"
                    + TZO.scriptName + "_dllink' target='_blank'><em>Download&#160;.torrent</em></a>");
                  }
                }
              // end download .torrent links
              });
            // end torrent-page
            })();
            
            // Select to search
            (function(){
              var titleEl           = $j("h2:eq(0)"),
                  injectEl          = downloadDiv.find(" > dl:eq(0)"),
                  searchBar,
                  searchLinks,
                  theOrgText,
                  theOldText,
                  searchHelperText,
                  unselectSelection,
                  noModKeys,
                  handleEscape
              ;
              titleEl.attr("title","Select the text in this title to start searching...");
              titleEl.after("<div id='search_bar'></div>");
              searchBar = $j("#search_bar");
              if (!_window.TzaioSelect) {
                TzaioSelect = {};
              }
              TzaioSelect.Selector = {};
              TzaioSelect.Selector.getSelected = function() {
                var t = "";
                if (_window.getSelection) {
                  t = _window.getSelection();
                } else if (document.getSelection) {
                  t = document.getSelection();
                } else if (document.selection) {
                  t = document.selection.createRange().text;
                }
                return t;
              }
              TzaioSelect.Selector.mouseup = function(e) {
                var st         = TzaioSelect.Selector.getSelected(),
                    tempStr,
                    _temp,
                    searchStr,
                    searchLink = "",
                    searchHtml = "",
                    leftOffset,
                    widthCalc,
                    cssWidth,
                    _searchEgi = [],
                    xOffset    = e.clientX,
                    yOffset    = e.clientY
                ;
                if (st != "") {
                  titleEl.removeAttr("title");
                  tempStr = st+"";
                  tempStr = tempStr
                    .replace(/(\W|\_)/ig," ")
                    .replace(/(torrent|download|locations)/ig,"")
                    .replace(/\s+/g," ")
                    .replace(/\s/g,"+")
                    .replace(/(^\+|\+$)/g,"");
                  searchStr = tempStr;
                  for ( var i = 0; i < storedSettings.searchEngines.length; i++ ) {
                    var engineHTMLArr = storedSettings.searchEngines[i].split("|");
                    searchHtml += "<a class='search_link' href='" + TZO.cloakerUrl
                      + engineHTMLArr[1].replace(/%s/g,searchStr).replace("http://www.nullrefer.com/?","")
                      + "'>" + engineHTMLArr[0].replace(/_/g," ") + "</a>";
                  }
                  searchHtml += "<a class='search_link' href='"
                    + "/search?f="+searchStr+"'>torrentz</a><a href='/feed?q=" + searchStr
                    + "'><img src='//"+TZO.docDomain+"/img/rss.png' width='16' height='16'></a>";
                  if (searchStr != "") {
                    searchBar.html(searchHtml);
                    TZO.bodyEl.addClass("search_ready");
                  }
                } else {
                  handleEscape(false, true);
                }
              }
              titleEl.bind("mouseup", TzaioSelect.Selector.mouseup);
              titleEl.bind("mousedown", function(){
                searchBar.empty();
                TZO.bodyEl.removeClass("search_ready");
              });
              unselectSelection = function() {
                // be nice, unselect the selected text
                // todo: browser compatible? works in safari, chrome, firefox            
                _window.getSelection().collapseToStart();
              }
              noModKeys = function(i) {
                function isF(x){
                  if ( _.isBoolean(x) && x === false ) return true;
                }
                function isD(y){
                  return y !== undefined;
                }
                if ( isD(i.ctrlKey) && isD(i.shiftKey) && isD(i.altKey) && isD(i.metaKey) ) {
                  return isF(i.ctrlKey) && isF(i.shiftKey) && isF(i.altKey) && isF(i.metaKey);
                }
              }
              handleEscape = function(e, unselected) { 
                if (unselected || +e.which === 27 && noModKeys(e)) {
                  // strange range error but nothing breaks
                  try {
                    titleEl.length && titleEl.trigger("mousedown");
                    searchBar.length && searchBar.empty();
                    TZO.bodyEl.removeClass("search_ready");
                    TZO.copyTextarea.length && TZO.copyTextarea.stop().hide(0);
                    TZO.topDiv.hasClass("expand") && TZO.topDiv.find(" > ul > li."+TZO.scriptName+"_settings a").trigger("click");
                    unselectSelection();
                  } catch(e) {
                    typeof GM_log === "function" && GM_log(e);
                  }
                }
              }
              $j(document).keyup(handleEscape);
            // end select-search
            })();
            
          // Splash page
          } else if (location.pathname === "/") {
            if ( storedSettings.removeAds ) {
              (function(){
                // Old Ads that might popup later again
                var frontPageAd = TZO.bodyEl.find(" > p a img");
                if (frontPageAd.length && frontPageAd.parent().parent().is("p")) frontPageAd.parent().parent().hide();
              })();
            }
            
          // Help Page
          } else if ( (/^help\/?$/).test(TZO.torrHash) ) {
            (function(){
              $j("div.help:eq(0)").append("<p><b>Torrentz All-in-One UserScript</b></p><ul>\
<li>Installed: "+TZO.scriptVersion+"</li>\
<li>Homepage: <a href='"+TZO.scriptHomepage+"'>"+TZO.scriptHomepage+"</a></li>\
<li>Github: <a href='https://github.com/elundmark/tz-aio-userscript'>https://github.com/elundmark/tz-aio-userscript</a></li>\
<li>Report issues here: <a href='https://github.com/elundmark/tz-aio-userscript'>https://github.com/elundmark/tz-aio-userscript/issues</a></li>\
<li>Built using <a href='http://www.jquery.com/'>jQuery</a>, \
<a href='http://underscorejs.org/'>underscore.js</a>, \
<a href='http://www.jstorage.info/'>jStorage</a>, \
<a href='http://code.google.com/p/jquery-json/'>jQuery JSON Plugin</a> \
&amp; the <a href='http://github.com/cowboy/jquery-replacetext/'>jQuery replaceText Plugin</a>.</li>\
</ul>");
            })();
          // Searchresults ( The /i page uses ajax so let's skip that
          } else if ( /^(search|any|verified|advanced|tracker_)/i.test(TZO.torrHash) ) {
            if ( storedSettings.removeAds ) {
              (function(){
                var resultsEl = $j("div.results:eq(0)");
                if ( resultsEl.find("h2").text().match(/sponsored/i) ) {
                  resultsEl.addClass("removed_ad");
                }
                resultsEl.prev().has("a img").addClass("removed_ad")
                $j("body > div.sponsored").addClass("removed_ad");
              })();
            }
            (function(){
              var searchParameters = document.location.search.match(/^\?f\=(.+)$/i),
                  resultsEl        = $j("div.results:visible:eq(0)"),
                  resultsH2        = resultsEl.find(" > h2"),
                  widthsObj        = null,
                  genreArr,
                  genreArrLength,
                  colorize,
                  dmcaDl
              ;
              if ( storedSettings.searchHighlight ) {
                genreArr = [
[ "pink",    new RegExp(unescape("%28%70%72%6F%6E%7C%70%6F%72%6E%7C%70%30%72%6E%7C%70%72%30%6E%7C%78\
%78%78%7C%61%64%75%6C%74%7C%5C%62%73%65%78%5C%62%7C%5C%62%31%38%5C%2B%3F%5C%62%29"), "i") ],
[ "tv",      /(\btv\b|eztv|ettv|tvteam|television|series|shows|episodes)/i ],
[ "movie",   /(movie|xvid|divx|bdrip|hdrip|maxspeed|klaxxon|axxo|wmv|avi|matroska|mkv|highres|264)/i ],
[ "game",    /game/i ],
[ "book",    /(book|epub|pdf|document|m4b|audiobook|audible|comics)/i ],
[ "music",   /(music|audio|\bpop\b|\brock\b|flac|lossless|consert|bootleg|mp3|ogg|wav|m4a)/i ],
[ "app",     /(software|applications|apps|\bos\b)/i ],
[ "picture", /(picture|images|gallery)/i ],
[ "anime",   /anime\b/i ],
[ "movie",   /(video|1080p|720p)/i ],
[ "app",     /(\bos\b|\bunix\b|\blinux\b|\bsolaris\b|\bwindows\b|\bmac\b|\bx64\b|\bx86\b)/i ],
[ "misc",    /(other|misc|miscellaneous|unsorted|siterip)/i ]
                ];
                genreArrLength = genreArr.length;
                colorize = function(x, e) {
                   // I've tried to optimize this to make it faster but this is the best I could do
                  var el             = $j(e),
                      dtEl           = $j("dt", el),
                      elLink         = $j("a", el),
                      statsDd        = el.find("dd"),
                      // avoid errors as much as possible
                      torrString     = dtEl.length ? dtEl.text() : "",
                      showTitle      = torrString.length > 89 ? torrString : null,
                      matchKeywords  = torrString.replace(/^.*»\s+?(.*)$/i, "$1"),
                      matchTitle     = torrString.replace(/^(.*)\s+?».*$/i, "$1").replace("'",""),
                      matchKeywords  = matchKeywords.length ? matchKeywords : torrString,
                      matchTitle     = matchTitle.length ? matchTitle : torrString,
                      i              = 0,
                      magnetUrl
                  ;
                  if ( !widthsObj ) {
                    widthsObj = { dt : (dtEl.width() - 24), dd : (statsDd.width() + 24) };
                  }
                  if ( elLink.length && dtEl.length ) {
                    // magnet link
                    magnetUrl = "magnet:?xt=urn:btih:" + elLink.attr("href").match(/\w{40}/i)[0]
                    + "&amp;dn=" + encodeURIComponent( matchTitle )
                    + "&amp;tr=" + TZO.trackerObject.userString.replace(/\n+/g,"&amp;tr=");
                    el.find("dd").prepend("<span class='magnet'><a href='" + magnetUrl + "' title='Download with magnetlink "
                    + "(" + TZO.trackerObject.userArray.length + " trackers)'>&nbsp;</a></span>")
                    /*
                    .end().click(function(e){
                      var $target = e.target !== undefined ? $(e.target) : null,
                        $this = $(this),
                        $link
                      ;
                      if ( $target && !$target.is("a") ) {
                        $link = $this.find("> dt > a");
                        $link = $link.attr("href").match(/\/[a-zA-Z0-9]{40}/) ? $link.attr("href") : null;
                        $link && ( location.href = $link );
                        return false;
                      }
                    })
                    */
                    ;
                    showTitle && ( el.attr("title", showTitle) );
                    // Keyword check
                    for (i; i < genreArrLength; i++) {
                      if ( genreArr[i][1].test(matchKeywords) ) {
                        el.addClass( genreArr[i][0] );
                        break;
                      }
                    }
                  }
                }
                // Add class to 'X results removed in compliance with EUCD / DMCA' first
                dmcaDl = resultsEl.find("dl:last");
                if ( dmcaDl.text().match(/removed.+compliance/i) ) {
                  dmcaDl.addClass("dmca");
                }
                resultsEl.find("dl").each(colorize);
                TZO.addStyle( TZO.searchCss() );
                TZO.addStyle( "div.results > dl > dt { width: " + widthsObj.dt + "px !important; }"
                  + "div.results > dl > dd { width: " + widthsObj.dd + "px !important; }" );
              }
              // Add rss link for "approximate match" results
              if ( searchParameters
                && searchParameters[1]
                && resultsEl.has("dl").length
                && resultsH2.length
                && !resultsH2.has("img[src*='rss.png']").length ) {
                resultsH2.append(
                  " <a class='approximate_rss_link' href='/feed?q="
                  + searchParameters[1]
                  + "'><img width='16' height='16' src='//"+TZO.docDomain+"/img/rss.png'></a>"
                );
              }
            })();
          // end pages
          }
          // easier debuggery
          _window["debug_"+TZO.scriptName] = TZO;
        // *****************************************************************************************
        }
      // end init
      }
      // call init with window and jQuery from best to worst solution
      init();
    // end if !=== https:
    }
  } catch(e) {
    typeof GM_log === "function" && GM_log(e);
  // end GM error logger
  }
}((unsafeWindow||window), (jQuery||unsafeWindow.jQuery||window.jQuery)));