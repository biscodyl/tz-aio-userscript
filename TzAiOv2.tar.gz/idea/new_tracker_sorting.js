#!/usr/bin/node

var newlineDelimiter = function (arr) {
  var newString = "",
    next        = null,
    i
  ;
  for (i = 0; i < arr.length; i++) {
    next = (i+1) < arr.length ? arr[(i+1)] : "";
    if ( next.replace(/^udp/,"").replace(/\/$/,"").replace(/:80\/?/,"")
      == arr[i].replace(/^https?/,"").replace(/\/$/,"").replace(/:80\/?/,"") ) {
      newString += arr[i] + "\n";
    } else {
      newString += arr[i] + "\n\n";
    }
  }
  newString = newString.replace(/\n+$/,"");
  return newString;
};

var finalTrackerSorting = function (_arr) {
  var newArr  = [],
    udpPopped = null,
    prev      = null,
    i
  ;
  for ( i = 0; i < _arr.length; i++ ) {
    udpPopped = null;
    prev = i >= 1 ? _arr[(i-1)] : "";
    if ( prev.replace(/^udp/,"") == _arr[i].replace(/^https?/,"") ) {
      udpPopped = newArr.pop();
      newArr.push(_arr[i]);
      newArr.push(udpPopped);
    } else {
      newArr.push(_arr[i]);
    }
  }
  return newArr;
};

// var patt = /(https?|udp):\/\/(www\.)?([^.]*)\.(.*\.?)*|\2\2/i;
var i;
var x;
var domains = [
  "udp://tracker.istole.it:80/",
  "udp://tracker.prq.to/announce",
  "udp://tracker.openbittorrent.com:80/",
  "udp://tracker.ccc.de",
  "http://192.168.1.1:80",
  "udp://tracker.publicbt.com:80/",
  "udp://bt1.the9.com:6969/announce",
  "http://inferno.demonoid.com:3407/announce",
  "http://tracker.ilibr.org:6969/announce",
  "http://tracker.istole.it:80/",
  "http://tracker.prq.to",
  "http://tracker.torrent.to:2710/announce",
  "udp://192.168.1.1",
  "http://9.rarbg.com:2710/announce",
  "http://bt1.the9.com:6969/announce",
  "http://exodus.desync.com:6969/announce",
  "http://genesis.1337x.org:1337/announce",
  "http://nemesis.1337x.org:80/announce",
  "http://old.nemesis.1337x.org:80/announce",
  "udp://192.168.1.1:80/announce",
  "udp://exodus.desync.com:6969/announce/"
];
var sortingArray = [];
var newArray;
var sortedString;
var cleanHost;
var slashMatch;
var test;
var domainSplit;
var domainSplitLen;
var mySortFunc = function (a,b) {
  var i = 0;
  if ( a[0] > b[0] ) {
    i = 1;
  } else if ( a[0] < b[0] ) {
    i = -1;
  }
  return i;
};
// tr: add to makeTrackersFunction
var extractLeveledArray = function ( arr ) {
  var returnArr = [], i;
  for ( i = 0; i < arr.length; i++ ) {
    returnArr.push( arr[i][1] );
  }
  return returnArr;
};


for ( i = 0; i < domains.length; i++ ) {
  slashMatch = domains[i].split("/").length - 1;
  if ( slashMatch >= 2 && domains[i].indexOf("://") !== -1 ) {
    cleanHost = domains[i].replace(/^[^\/]*\/+/i,"");
  } else {
    cleanHost = domains[i];
  }
  cleanHost = cleanHost.replace(/(:[0-9]+|\/).*$/i,"");
  if ( !cleanHost.match(/[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/) && (cleanHost.split(".").length - 1) > 1 ) {
    domainSplit = cleanHost.split(".");
    domainSplitLen = domainSplit.length;
    cleanHost = domainSplit[(domainSplitLen-2)] + "." + domainSplit[(domainSplitLen-1)];
  }
  sortingArray.push( [ cleanHost.toLowerCase(), domains[i] ] );
}

newArray = extractLeveledArray( sortingArray.sort(mySortFunc), 1 );
newArray = finalTrackerSorting( newArray );
sortedString = newlineDelimiter( newArray );
console.log( newArray );
console.log( sortedString );