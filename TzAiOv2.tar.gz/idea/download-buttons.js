// select the links we want to downloadify
var torCacheUrl        = "http://torcache.net/torrent/" + TZO.torrHash.toUpperCase() + ".torrent?title=" + TZO.torrentTitles.encoded,
  torRageUrl         = "http://torrage.com/torrent/" + TZO.torrHash.toUpperCase() + ".torrent",
  torrSitesArr       = [
    [ "movietorrents.eu",
      function(theUrl){
        // movietorrents.eu/torrents-details.php?id=1421
        // movietorrents.eu/download.php?id=1421&name=Ubuntu%20iso%20file.torrent
        // last checked 2012-07-25
        return ( "http://movietorrents.eu/download.php?id=" + theUrl.match(/(\?|&)id=(\d+)/)[2]
          + "&name=" + TZO.torrentTitles.encoded + ".torrent" );
      }
    ],
    [ "publichd.eu",
      function(theUrl){
        // publichd.eu/index.php?page=torrent-details&id=bae62a9932ec69bc6687a6d399ccb9d89d00d455
        // publichd.eu/download.php?id=bae62a9932ec69bc6687a6d399ccb9d89d00d455&f=ubuntu-10.10-dvd-i386.iso.torrent
        // last checked 2012-07-23
        return ( "http://publichd.eu/download.php?id=" + TZO.torrHash.toLowerCase() + "&f=" + TZO.torrentTitles.encoded + ".torrent" );
      }
    ],
    [ "btmon.com",
      function(theUrl){
        // www.btmon.com/Applications/Unsorted/ubuntu-10.10-dvd-i386.iso.torrent.html
        // www.btmon.com/Applications/Unsorted/ubuntu-10.10-dvd-i386.iso.torrent
        // last checked 2012-05-13
        return ( theUrl.replace(/\.html$/i, "") );
      }
    ],
    [ "torrentdownloads.net",
      function(theUrl){
        // www.torrentdownloads.net/torrent/1652094016/ubuntu-10+10-desktop-i386+iso
        // www.torrentdownloads.net/download/1652094016/ubuntu-10+10-desktop-i386+iso
        // last checked 2012-05-13
        return ( theUrl.replace(/(\.net\/)torrent(\/)/i,"$1download$2") );
      }
    ],
    [ "kat.ph",
      function(theUrl){
        // www.kickasstorrents.com/ubuntu-10-10-dvd-i386-iso-t4657293.html
        // torcache.net/torrent/BAE62A9932EC69BC6687A6D399CCB9D89D00D455.torrent?title=[kat.ph]ubuntu-10-10-dvd-i386
        // last checked 2012-05-13
        return ( torCacheUrl );
      }
    ],
    [ "kickasstorrents.com",
      function(theUrl){
        // www.kickasstorrents.com/ubuntu-10-10-dvd-i386-iso-t4657293.html
        // torcache.net/torrent/BAE62A9932EC69BC6687A6D399CCB9D89D00D455.torrent?title=[kat.ph]ubuntu-10-10-dvd-i386
        // last checked 2012-05-13
        return ( torCacheUrl );
      }
    ],
    [ "h33t.com/tor",
      function(theUrl){
        // h33t.com/tor/999999/ubuntu-10.10-dvd-i386.iso-h33t
        // h33t.com/download.php?id=bae62a9932ec69bc6687a6d399ccb9d89d00d455&f=Ubuntu%2010.10%20-%20DVD%20-%20i386.iso.torrent
        // last checked 2012-05-13
        return ( "http://h33t.com/download.php?id=" + TZO.torrHash.toLowerCase() + "&f="
                +TZO.torrentTitles.encoded + "%5D%5Bh33t%5D.torrent" );
      }
    ],
    [ "newtorrents.info/torrent",
      function(theUrl){
        // www.newtorrents.info/torrent/99999/Ubuntu-10-10-DVD-i386.html?nopop=1
        // www.newtorrents.info/down.php?id=99999
        // last checked 2012-05-13
        var theUrlArr = theUrl.split("/");
        return ( "http://" + theUrlArr[2] + "/down.php?id=" + theUrlArr[4] );
      }
    ],
    [ "fenopy.eu/torrent",
      function(theUrl){
        // fenopy.com/torrent/ubuntu+10+10+dvd+i386+iso/NjMxNjcwMA
        // fenopy.com/torrent/ubuntu+10+10+dvd+i386+iso/NjMxNjcwMA==/download.torrent
        // seems to use torcache but this works too
        // last checked 2012-05-13
        return ( theUrl + "==/download.torrent" );
      }
    ],
              [ "extratorrent.com/torrent",
                function(theUrl){
                  // extratorrent.com/torrent/9999999/Ubuntu-10-10-DVD-i386.html
                  // extratorrent.com/download/9999999/Ubuntu-10-10-DVD-i386.torrent
                  // last checked 2012-05-13
                  return ( theUrl.replace(/(\.com\/torrent)/i, ".com/download").replace(/\.html$/i, ".torrent") );
                }
              ],
              [ "bitsnoop.com",
                function(theUrl){
                  // bitsnoop.com/ubuntu-10-10-dvd-i386-q17900716.html
                  // torrage.com/torrent/BAE62A9932EC69BC6687A6D399CCB9D89D00D455.torrent
                  // last checked 2012-05-13
                  return ( torRageUrl );
                }
              ],
            [ "bt-chat.com",
              function(theUrl){
                // www.bt-chat.com/details.php?id=999999
                // www.bt-chat.com/download.php?id=999999
                // last checked 2012-05-13
                // Site was malware flagged so I don't know if this still works
                return ( theUrl.replace(/\/details\.php/i, "/download.php") );
              }
            ],
            [ "1337x.org",
              function(theUrl){
                // 1337x.org/torrent/999999/ubuntu-10-10-dvd-i386/
                // last checked 2012-05-13
                return ( torCacheUrl );
              }
            ],
            [ "torrentfunk.com/torrent/",
              function(theUrl){
                // www.torrentfunk.com/torrent/9999999/ubuntu-10-10-dvd-i386.html
                // www.torrentfunk.com/tor/9999999.torrent
                // last checked 2012-05-13
                var theUrlArr = theUrl.split("/");
                return ( "http://www.torrentfunk.com/tor/" + theUrlArr[4] + ".torrent" );
              }
            ],
            [ "torrentstate.com",
              function(theUrl){
                // www.torrentstate.com/ubuntu-10-10-dvd-i386-iso-t4657293.html
                // www.torrentstate.com/download/BAE62A9932EC69BC6687A6D399CCB9D89D00D455
                // last checked 2012-05-13
                // Site was down so I don't know if this still works
                return ( "http://www.torrentstate.com/download/" + TZO.torrHash.toUpperCase() );
              }
            ],
            [ "torlock.com/torrent/",
              function(theUrl){
                // www.torlock.com/torrent/1702956/21-jump-street-2012-r5-new-line-inspiral.html
                // dl.torlock.com/1702956.torrent
                // last checked 2012-05-13
                var theUrlArr = theUrl.split("/");
                return ( "http://dl.torlock.com/" + theUrlArr[4] + ".torrent" );
              }
            ],
            [ "torrenthound.com/hash",
              function(theUrl){
                // www.torrenthound.com/hash/bae62a9932ec69bc6687a6d399ccb9d89d00d455/torrent-info/ubuntu-10.10-dvd-i386.iso
                // www.torrenthound.com/torrent/bae62a9932ec69bc6687a6d399ccb9d89d00d455
                // last checked 2012-05-13
                return ( "http://www.torrenthound.com/torrent/" + TZO.torrHash );
              }
            ],
            [ "vertor.com/torrents",
              function(theUrl){
                // www.vertor.com/torrents/2191958/Ubuntu-10-10-Maverick-Meerkat-%28Desktop-Intel-x86%29
                // www.vertor.com/index.php?mod=download&id=2191958
                // last checked 2012-05-13
                var theUrlArr = theUrl.split("/");
                return ( "http://www.vertor.com/index.php?mod=download&id=" + theUrlArr[4] );
              }
            ],
            [ "yourbittorrent.com/torrent/",
              function(theUrl){
                // www.yourbittorrent.com/torrent/212911/ubuntu-10-10-desktop-i386-iso.html
                // www.yourbittorrent.com/down/212911.torrent
                // last checked 2012-05-13
                var theUrlArr = theUrl.split("/");
                return ( "http://yourbittorrent.com/down/" + theUrlArr[4] + ".torrent" );
              }
            ],
            [ "torrents.net/torrent",
              function(theUrl){
                // www.torrents.net/torrent/9999999/Ubuntu-10-10-DVD-i386.html/
                // www.torrents.net/down/9999999.torrent
                // last checked 2012-05-13
                var theUrlArr = theUrl.split("/");
                return ( "http://www.torrents.net/down/" + theUrlArr[4] + ".torrent" );
              }
            ],
            [ "torrentbit.net/torrent",
              function(theUrl){                  
                // www.torrentbit.net/torrent/1903618/Ubuntu11.04%20Desktop%20i386%20ISO/
                // www.torrentbit.net/get/1903618
                // last checked 2012-05-13
                var theUrlArr = theUrl.split("/");
                return ( "http://www.torrentbit.net/get/" + theUrlArr[4] );
              }
            ],
            [ "coda.fm/albums",
              function(theUrl){                  
                // coda.fm/albums/9999
                // coda.fm/albums/9999/torrent/download?file=Title+of+torrent.torrent
                // last checked 2012-05-13
                var theUrlArr = theUrl.split("/");
                return ( "http://coda.fm/albums/" + theUrlArr[4] + "/torrent/download?file="
                        +TZO.torrentTitles.encoded + ".torrent" );
              }
            ],
            [ "take.fm/movies",
              function(theUrl){                  
                // take.fm/movies/999/releases/9999
                // take.fm/movies/999/releases/9999/torrent/download?file=Title+of+torrent.torrent
                // last checked 2012-05-13
                var theUrlArr = theUrl.split("/");
                return ( "http://take.fm/movies/"+theUrlArr[4]+"/releases/"+theUrlArr[6]
                        +"/torrent/download?file="+TZO.torrentTitles.encoded+".torrent" );
              }
            ],
    [ "torrage.com/torrent",
      function(theUrl){
        // torrage.com/torrent/BAE62A9932EC69BC6687A6D399CCB9D89D00D455.torrent
        return theUrl;
      }
    ],
    [ "torcache.net/torrent",
      function(theUrl){
        // torcache.net/torrent/BAE62A9932EC69BC6687A6D399CCB9D89D00D455.torrent
        return theUrl;
      }
    ],
    [ "zoink.it/torrent",
      function(theUrl){
        // zoink.it/torrent/BAE62A9932EC69BC6687A6D399CCB9D89D00D455.torrent
        return theUrl;
      }
    ]
  ],
  linkList           = downloadDiv.find("a:not([href^='magnet']):not([href='"+TZO.scriptName + "_dllink'])"),
  torrSitesArrLength = torrSitesArr.length
;
linkList.each(function(){
  var theUrl    = this.href,
      theUrlLow = theUrl.toLowerCase(),
      theLink   = $j(this)
  ;
  for ( var j = 0; j < torrSitesArrLength; j++ ) {
    if ( theUrlLow.match(new RegExp(torrSitesArr[j][0],"i")) ) {
      theLink.before("<a href='" + torrSitesArr[j][1](theUrl) + "' class='"
      + TZO.scriptName + "_dllink' target='_blank'><em>Download&#160;.torrent</em></a>");
    }
  }
// end download .torrent links
});




// NEW

getDirectTorrentLinks     : function (href, hash, title, titleEnc) {
  if ( !href || !hash || !title || !titleEnc ) {
    sendLog("[getDirectTorrentLinks] is missing paramenters!");
    return;
  }
  var hash      = hash.toLowerCase(),
    HASH        = hash.toUpperCase(),
    torCacheUrl = "http://torcache.net/torrent/" + HASH + ".torrent?title=" + titleEnc,
    torRageUrl  = "http://torrage.com/torrent/" + HASH + ".torrent",
    directHref  = null,
    directMatch = null,
    slashSplit  = href.split("/")
  ;
  if ( ~href.indexOf("movietorrents.eu/") ) {
    // last checked 2012-07-25
    // movietorrents.eu/torrents-details.php?id=1421
    // movietorrents.eu/download.php?id=1421&name=Ubuntu%20iso%20file.torrent
    directMatch = href.match(/(\?|&)id=(\d+)/);
    directHref = directMatch && directMatch.length === 3 ? "http://movietorrents.eu/download.php?id="
      + directMatch[2] + "&name=" + titleEnc + ".torrent" : null;
  } else if ( ~href.indexOf("publichd.eu/") ) {
    // last checked 2012-07-23
    // publichd.eu/index.php?page=torrent-details&id=bae62a9932ec69bc6687a6d399ccb9d89d00d455
    // publichd.eu/download.php?id=bae62a9932ec69bc6687a6d399ccb9d89d00d455&f=ubuntu-10.10-dvd-i386.iso.torrent
    directHref = "http://publichd.eu/download.php?id=" + hash + "&f=" + titleEnc + ".torrent";
  } else if ( ~href.indexOf("btmon.com/") ) {
    // last checked 2012-05-13
    // www.btmon.com/Applications/Unsorted/ubuntu-10.10-dvd-i386.iso.torrent.html
    // www.btmon.com/Applications/Unsorted/ubuntu-10.10-dvd-i386.iso.torrent
    directHref = href.replace(/\.html$/i, "");
  } else if ( ~href.indexOf("torrentdownloads.net/") ) {
    // last checked 2012-05-13
    // www.torrentdownloads.net/torrent/1652094016/ubuntu-10+10-desktop-i386+iso
    // www.torrentdownloads.net/download/1652094016/ubuntu-10+10-desktop-i386+iso
    directHref = href.replace(/(\.net\/)torrent(\/)/i,"$1download$2");
  } else if ( ~href.indexOf("kat.ph/") || ~href.indexOf("kickasstorrents.com/") ) {
    // last checked 2012-05-13
    // www.kickasstorrents.com/ubuntu-10-10-dvd-i386-iso-t4657293.html
    // torcache.net/torrent/BAE62A9932EC69BC6687A6D399CCB9D89D00D455.torrent?title=[kat.ph]ubuntu-10-10-dvd-i386
    directHref = torCacheUrl;
  } else if ( ~href.indexOf("h33t.com/tor") ) {
    // last checked 2012-05-13
    // h33t.com/tor/999999/ubuntu-10.10-dvd-i386.iso-h33t
    // h33t.com/download.php?id=bae62a9932ec69bc6687a6d399ccb9d89d00d455&f=Ubuntu%2010.10%20-%20DVD%20-%20i386.iso.torrent
    directHref = "http://h33t.com/download.php?id=" + hash + "&f=" + titleEnc + "%5D%5Bh33t%5D.torrent";
  } else if ( ~href.indexOf("newtorrents.info/torrent") ) {
    // last checked 2012-05-13
    // www.newtorrents.info/torrent/99999/Ubuntu-10-10-DVD-i386.html?nopop=1
    // www.newtorrents.info/down.php?id=99999
    directHref = slashSplit && slashSplit.length >= 5 ? "http://" + slashSplit[2]
      + "/down.php?id=" + slashSplit[4] : null;
  } else if ( ~href.indexOf("fenopy.eu/torrent") ) {
    // last checked 2012-05-13
    // fenopy.com/torrent/ubuntu+10+10+dvd+i386+iso/NjMxNjcwMA
    // fenopy.com/torrent/ubuntu+10+10+dvd+i386+iso/NjMxNjcwMA==/download.torrent
    // seems to use torcache but this works too
    directHref = href + "==/download.torrent";
  } else if ( ~href.indexOf("extratorrent.com/torrent") ) {
    // last checked 2012-05-13
    // extratorrent.com/torrent/9999999/Ubuntu-10-10-DVD-i386.html
    // extratorrent.com/download/9999999/Ubuntu-10-10-DVD-i386.torrent
    directHref = href.replace(/(\.com\/torrent)/i, ".com/download").replace(/\.html$/i, ".torrent");
  } else if ( ~href.indexOf("bitsnoop.com/") ) {
    // last checked 2012-05-13
    // bitsnoop.com/ubuntu-10-10-dvd-i386-q17900716.html
    // torrage.com/torrent/BAE62A9932EC69BC6687A6D399CCB9D89D00D455.torrent
    directHref = torRageUrl;
  } else if ( ~href.indexOf("bt-chat.com/") ) {
    // last checked 2012-05-13
    // Site was malware flagged so I don't know if this still works
    // www.bt-chat.com/details.php?id=999999
    // www.bt-chat.com/download.php?id=999999
    directHref = href.replace(/\/details\.php/i, "/download.php");
  } else if ( ~href.indexOf("1337x.org/") ) {
    // last checked 2012-05-13
    // 1337x.org/torrent/999999/ubuntu-10-10-dvd-i386/
    directHref = torCacheUrl;
  } else if ( ~href.indexOf("torrentfunk.com/torrent/") ) {
    // last checked 2012-05-13
    // www.torrentfunk.com/torrent/9999999/ubuntu-10-10-dvd-i386.html
    // www.torrentfunk.com/tor/9999999.torrent
    directHref = slashSplit && slashSplit.length >= 5 ? "http://www.torrentfunk.com/tor/"
      + slashSplit[4] + ".torrent" : null;
  } else if ( ~href.indexOf("torrentstate.com/") ) {
    // last checked 2012-05-13
    // Site was down so I don't know if this still works
    // www.torrentstate.com/ubuntu-10-10-dvd-i386-iso-t4657293.html
    // www.torrentstate.com/download/BAE62A9932EC69BC6687A6D399CCB9D89D00D455
    directHref = "http://www.torrentstate.com/download/" + HASH;
  } else if ( ~href.indexOf("torlock.com/torrent/") ) {
    // last checked 2012-05-13
    // www.torlock.com/torrent/1702956/21-jump-street-2012-r5-new-line-inspiral.html
    // dl.torlock.com/1702956.torrent
    directHref = slashSplit && slashSplit.length >= 5 ? "http://dl.torlock.com/"
      + slashSplit[4] + ".torrent" : null;
  } else if ( ~href.indexOf("torrenthound.com/hash") ) {
    // last checked 2012-05-13
    // www.torrenthound.com/hash/bae62a9932ec69bc6687a6d399ccb9d89d00d455/torrent-info/ubuntu-10.10-dvd-i386.iso
    // www.torrenthound.com/torrent/bae62a9932ec69bc6687a6d399ccb9d89d00d455
    directHref = "http://www.torrenthound.com/torrent/" + hash;
  } else if ( ~href.indexOf("vertor.com/torrents") ) {
    // last checked 2012-05-13
    // www.vertor.com/torrents/2191958/Ubuntu-10-10-Maverick-Meerkat-%28Desktop-Intel-x86%29
    // www.vertor.com/index.php?mod=download&id=2191958
    directHref = slashSplit && slashSplit.length >= 5 ? "http://www.vertor.com/index.php?mod=download&id="
      + slashSplit[4] : null;
  } else if ( ~href.indexOf("yourbittorrent.com/torrent/") ) {
    // last checked 2012-05-13
    // www.yourbittorrent.com/torrent/212911/ubuntu-10-10-desktop-i386-iso.html
    // www.yourbittorrent.com/down/212911.torrent
    directHref = slashSplit && slashSplit.length >= 5 ? "http://yourbittorrent.com/down/"
      + slashSplit[4] + ".torrent" : null;
  } else if ( ~href.indexOf("torrents.net/torrent") ) {
    // last checked 2012-05-13
    // www.torrents.net/torrent/9999999/Ubuntu-10-10-DVD-i386.html/
    // www.torrents.net/down/9999999.torrent
    directHref = slashSplit && slashSplit.length >= 5 ? "http://www.torrents.net/down/"
      + slashSplit[4] + ".torrent" : null;
  } else if ( ~href.indexOf("torrentbit.net/torrent") ) {
    // last checked 2012-05-13
    // www.torrentbit.net/torrent/1903618/Ubuntu11.04%20Desktop%20i386%20ISO/
    // www.torrentbit.net/get/1903618
    directHref = slashSplit && slashSplit.length >= 5 ? "http://www.torrentbit.net/get/"
      + slashSplit[4] : null;
  } else if ( ~href.indexOf("coda.fm/albums") ) {
    // last checked 2012-05-13
    // coda.fm/albums/9999
    // coda.fm/albums/9999/torrent/download?file=Title+of+torrent.torrent
    directHref = slashSplit && slashSplit.length >= 5 ? "http://coda.fm/albums/"
      + slashSplit[4] + "/torrent/download?file=" + titleEnc + ".torrent" : null;
  } else if ( ~href.indexOf("take.fm/movies") ) {
    // last checked 2012-05-13
    // take.fm/movies/999/releases/9999
    // take.fm/movies/999/releases/9999/torrent/download?file=Title+of+torrent.torrent
    directHref = slashSplit && slashSplit.length >= 7 ? "http://take.fm/movies/" + slashSplit[4]
      + "/releases/" + slashSplit[6] + "/torrent/download?file=" + titleEnc + ".torrent" : null;
  } else if ( ~href.indexOf("torrage.com/torrent") ) {
    // torrage.com/torrent/BAE62A9932EC69BC6687A6D399CCB9D89D00D455.torrent
    directHref = href;
  } else if ( ~href.indexOf("torcache.net/torrent") ) {
    // torcache.net/torrent/BAE62A9932EC69BC6687A6D399CCB9D89D00D455.torrent
    directHref = href;
  } else if ( ~href.indexOf("zoink.it/torrent") ) {
    // zoink.it/torrent/BAE62A9932EC69BC6687A6D399CCB9D89D00D455.torrent
    directHref = href;
  }
  return directHref;
},

doDirectTorrentLink       : function (index, link) {
  var dlink = link && link.href ? this.getDirectTorrentLinks(link.href, this.page.hash, title, titleEnc) : null;
  if ( dlink ) {
    // link.href >> link.href = dlink;
  }
},


tzAio.selectors.$downloadDiv
  .find("a:not([href^='magnet']):not([href='" + tzAio.userScript.slug + "_dllink'])")
  .each(tzAio.doDirectTorrentLink);