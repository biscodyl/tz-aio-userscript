// create all-in-one bar
              var currTrackerList= [],
                  trackersDiv    = $j("div.trackers:eq(0)"),
                  trackerLinks   = trackersDiv.find("dt a"),
                  trackerDataEls = trackersDiv.find("dl:has(a) dd"),
                  trackerLen,
                  torrTitle      = $j("h2:eq(0) span").text(),
                  mg_trackerList = "",
                  magnetLinkHtml = "",
                  announceUrl    = trackersDiv.find(" > p > a[href*='announcelist_']").attr("href"),
                  finalHtml      = "",
                  upElems        = trackerDataEls.find(".u"),
                  downElems      = trackerDataEls.find(".d"),
                  dhtEls         = trackersDiv.find("dl:eq(0):contains('(DHT)') span.u, dl:eq(0):contains('(DHT)') span.d"),
                  _up            = [],
                  _down          = [],
                  upNum          = 0,
                  downNum        = 0,
                  topUpNum       = 0,
                  topDownNum     = 0,
                  seedMeter      = 0,
                  seedTleach,
                  seedColor      = TZO.colors.black,
                  seedText,
                  minPeersText,
                  seedTitle      = "S<span class='divided'>&frasl;</span>L &asymp;",
                  filesDiv       = $j("div.files"),
                  fileLinks      = $j("a", filesDiv),
                  filesInfoText,
                  wmvWarning     = false,
                  notActive      = !!(downloadDiv.next(".error").text().match(/active\s+locations?/i)),
                  verDownload    = $j(".votebox .status").text().match(/\d+/),
                  verDownloadCl  = (verDownload && +verDownload[0] >= 3) && !notActive ? " verified_download" : notActive ? " not_active" : "",
                  warn_blink_timer,
                  filesSizeText  = $j("div:contains('Size:'):eq(0)", filesDiv).text().replace("Size: ",""),
                  commentDiv     = $j("div.comments"),
                  formFieldset   = $j("form.profile fieldset"),
                  commentCount   = $j(".comment", commentDiv).length,
                  htmlDivider    = " <span class='"+TZO.scriptName+"_sep'>&#124;</span> ",
                  trackersText,
                  commentText,
                  trackerNumText,
                  clippyText,
                  minPeers = 0,
                  formatNumbers  = function(i){
                    if ( i >= 1000 ) {
                      i = ""+i+"";
                      return (i.replace(/(\d+)(\d{3})$/,"$1,$2"));
                    } else {
                      return i;
                    }
                  }
              ;
              TZO.torrentTitles.raw = torrTitle;
              TZO.torrentTitles.encoded = encodeURIComponent( torrTitle.replace("'","") );
              trackerLinks.each(function() {
                // Will produce an empty array if there are no trackers on site
                currTrackerList.push( $j(this).text() );
              });
              TZO.trackerObject.siteArray = currTrackerList;
              TZO.trackerObject.siteString = TZO.mergeTrackers( [], TZO.trackerObject.siteArray, "string" );
              TZO.trackerObject.allArray = TZO.mergeTrackers( TZO.trackerObject.userArray, TZO.trackerObject.siteArray, "array" );
              TZO.trackerObject.allString = TZO.mergeTrackers( TZO.trackerObject.allArray, [], "string" );
              TZO.trackerObject.allMagnet = "magnet:?xt=urn:btih:" + TZO.torrHash + "&amp;dn="
              + TZO.torrentTitles.encoded + "&amp;tr=" + TZO.trackerObject.allString.replace(/\n+/g,"&amp;tr=");
              trackerLen = TZO.trackerObject.allArray.length;
              trackersText = trackerLen > 1 ? "trackers" : "tracker";
              // final magnetlink uri
              magnetLinkHtml = "<a class='"+TZO.scriptName+"_mlink' href='"
              + TZO.trackerObject.allMagnet 
              + "' title='Fully qualified magnet URI for newer BitTorrent clients, includes"
              + " all " + trackerLen + " " + trackersText + "'>Magnet Link</a>";
              // create seed leach ratio
              upElems.each(function(index) {
                _up[index]   = +$j(this).text().replace(/\D/g,"");
              });
              downElems.each(function(index) {
                _down[index] = +$j(this).text().replace(/\D/g,"");
              });
              for (var i = 0; i < _up.length; i++) {
                upNum += _up[i];
                if (i === 0) {
                  topUpNum = _up[i];
                } else if ( _up[i] > topUpNum ) {
                  topUpNum = _up[i];
                }
              }
              for (var i = 0; i < _down.length; i++) {
                downNum += _down[i];
                if (i === 0) {
                  topDownNum = _down[i];
                } else if ( _down[i] > topDownNum ) {
                  topDownNum = _down[i];
                }
              }
              // DHT activity
              minPeers = (topDownNum >= topUpNum) ? topDownNum : topUpNum;
              dhtEls.each(function(){
                var i = +$j(this).text().replace(/\D/g,"");
                if ( i > minPeers ) minPeers = i;
              });
              seedTleach = (upNum/downNum);
              seedTleach = ((topUpNum/topDownNum )+(seedTleach))/2;
              if (seedTleach === Infinity) {
                seedMeter = (upNum/_up.length).toFixed(2); // 8 divided by 0
              } else if (isNaN(seedTleach)) {
                seedMeter = 0; // 0 divided by 0
              } else if (seedTleach < 10) {
                seedMeter = seedTleach.toFixed(2);
              } else if (seedTleach >= 10 && seedTleach < 100) {
                seedMeter = seedTleach.toFixed(1);
              } else if (seedTleach >= 100) {
                seedMeter = Math.round(seedTleach);
              }
              if (seedMeter >= 2 && topUpNum >= 5 ) {
                seedColor = TZO.colors.green;
              }
              seedText = seedTitle + " <span style='color:" + seedColor + "'>" + seedMeter + "</span>";
              minPeersText = " <span>" + formatNumbers(minPeers) + "+ peers</span>";
              clippyText = "<a href='#' id='copylist' title='Click to copy the trackerlist'>Copy "
                          +TZO.trackerObject.allArray.length + " trackers</a>";
              if (commentCount) {
                commentText = "<a href='#comments_"+TZO.scriptName+"'>";
                commentDiv.attr("id","comments_"+TZO.scriptName);
              } else {
                commentText = "<a href='#write_comment_"+TZO.scriptName+"'>";
                formFieldset.attr("id","write_comment_"+TZO.scriptName);
              }
              commentText += "<img src='//"+TZO.docDomain+"/img/comment.png'/> " + commentCount+"</a>";
              fileLinks.filter("[href*='.wmv']").each(function(){
                if ( /\.wmv$/i.test($j(this).text()) ) {
                  wmvWarning = true;
                }
              });
              if (fileLinks.length) {
                $j("div.files:eq(0)").attr("id","files_"+TZO.scriptName);
                filesInfoText = "<a href='#files_"+TZO.scriptName+"'><img src='//"+TZO.docDomain+"/img/folder.png'/> " + fileLinks.length + "</a> &frasl; ";
              } else if (!fileLinks.length) {
                filesInfoText = "";
              }
              filesInfoText += filesSizeText.length ? filesSizeText : "";
              if ( filesInfoText.length && wmvWarning ) {
                filesInfoText += " <span class='warn'>.wmv</span>";
              }
              finalHtml += magnetLinkHtml;
              finalHtml += htmlDivider + clippyText;
              finalHtml += htmlDivider + minPeersText;
              finalHtml += htmlDivider + seedText;
              finalHtml += htmlDivider + commentText;
              finalHtml += filesInfoText.length ? htmlDivider + filesInfoText : "";
              finalHtml += " <a href='"+TZO.scriptHomepage+"' id='"+TZO.scriptName+"_logo'";
              finalHtml += " title='"+TZO.scriptVersion+"'>Tz Aio";
              finalHtml += "<span id='"+TZO.scriptName+"_message'>";
              finalHtml += "Visit Torrentz All-in-One Website ("+TZO.scriptVersion+")";
              finalHtml += "</span></a>";
              downloadDiv.before("<div id='" + TZO.scriptName + "' class='" + verDownloadCl + "'>" + finalHtml + "</div>");
              // edit torrentz own magnet link if avaliable
              downloadDiv.find("a[href^='magnet']").each(function(){
                $(this).attr("href", TZO.trackerObject.allMagnet
                                     .replace(/\&amp\;/ig,"&")
                                     .replace(/\&gt\;/ig,">")
                                     .replace(/\&lt\;/ig,"<")
                );
              });
              warn_blink_timer = setTimeout(function(){
                $j("#"+TZO.scriptName).find(".warn")
                .fadeOut(500).delay(550).fadeIn(500)
                .delay(550).fadeOut(500).delay(550).fadeIn(500)
                .delay(550).fadeOut(500).delay(550).fadeIn(500);
              }, 2000);
              // end info bar
              
              // Setup copy methods
              (function(){
                // flash method sux and has been abandoned
                var copylistEl   = $j("#copylist"),
                    copylistText = TZO.newlineDelimiter( TZO.trackerObject.allString ),
                    linkHeight   = copylistEl.outerHeight(),
                    theTextarea,
                    textareaHTML = "<div id='copy_tr_textarea'><textarea readonly='readonly' cols='40' rows='10' wrap='off'>"
                    + copylistText + "</textarea></div>"
                ;
                TZO.bodyEl.append(textareaHTML);
                TZO.copyTextarea = $j("#copy_tr_textarea");
                copylistEl.click(function(){
                  if ( TZO.copyTextarea.is(":hidden") ) {
                    TZO.copyTextarea.css({
                      top : (copylistEl.offset().top + linkHeight)+"px",
                      left : (copylistEl.offset().left)+"px"
                    }).show(0).find("textarea")[0].select();
                  } else {
                    TZO.copyTextarea.hide(0);
                  }
                  return false;
                });
              })();